package br.com.leonix.adapter;

import java.util.ArrayList;

import br.com.leonix.model.Chat;

public class ChatAdapter {
	private Chat chat = null;

	private ArrayList<Chat> chats = null;

	public ChatAdapter(Chat chat) {
		this.chat = chat;
	}

	public ChatAdapter(ArrayList<Chat> chats) {
		this.chats = chats;
	}

	public String getJson() {

		String jsonStr = "";

		if (this.chat != null) {
			jsonStr = String.format("{\"id\":%s,\"idUsuarioA\":\"%s\",\"idUsuarioB\":\"%s\",\"mensagem\":\"%s\"}", this.chat.getId(),
					this.chat.getIdUsuarioA(), this.chat.getIdUsuarioB(),this.chat.getMensagem());
		} else if (this.chats != null) {
			jsonStr = "[";
			for (Chat cht : this.chats) {
				if (cht.equals(this.chats.get(this.chats.size() - 1))) {
					jsonStr += String.format("{\"id\":%s,\"idUsuarioA\":\"%s\",\"idUsuarioB\":\"%s\",\"mensagem\":\"%s\"}", cht.getId(),
							cht.getIdUsuarioA(), cht.getIdUsuarioB(),cht.getMensagem());
				} else {
					jsonStr += String.format("{\"id\":%s,\"idUsuarioA\":\"%s\",\"idUsuarioB\":\"%s\",\"mensagem\":\"%s\"},", cht.getId(),
							cht.getIdUsuarioA(), cht.getIdUsuarioB(),cht.getMensagem());
				}
			}
			jsonStr += "]";
		}
		return jsonStr;
	}
}
