package br.com.leonix.adapter;

import java.util.ArrayList;
import br.com.leonix.model.Usuario;

public class UsuarioAdapter {

	private Usuario usuario = null;

	private ArrayList<Usuario> usuarios = null;

	public UsuarioAdapter(Usuario usuario) {
		this.usuario = usuario;
	}

	public UsuarioAdapter(ArrayList<Usuario> usuarios) {
		this.usuarios = usuarios;
	}

	public String getJson() {
		
		String jsonStr = "";
		
		if (this.usuario != null) {
			jsonStr = String.format("{\"id\":%s,\"nick\":\"%s\",\"senha\":\"%s\"}", this.usuario.getId(),
					this.usuario.getNick(), this.usuario.getSenha());
		} else if (this.usuarios != null) {
			jsonStr = "[";
			for (Usuario usr : this.usuarios) {
				if (usr.equals(this.usuarios.get(this.usuarios.size() - 1))) {
					jsonStr += String.format("{\"id\":%s,\"nick\":\"%s\",\"senha\":\"%s\"}", usr.getId(), usr.getNick(),
							usr.getSenha());
				} else {
					jsonStr += String.format("{\"id\":%s,\"nick\":\"%s\",\"senha\":\"%s\"},", usr.getId(),
							usr.getNick(), usr.getSenha());
				}
			}
			jsonStr += "]";
		}
		return jsonStr;
	}
}
