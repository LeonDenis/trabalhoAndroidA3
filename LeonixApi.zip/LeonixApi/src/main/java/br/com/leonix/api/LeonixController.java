package br.com.leonix.api;

import org.springframework.web.bind.annotation.RestController;

import br.com.leonix.adapter.AmigoAdapter;
import br.com.leonix.adapter.ChatAdapter;
import br.com.leonix.adapter.UsuarioAdapter;
import br.com.leonix.model.Amigo;
import br.com.leonix.model.Chat;
import br.com.leonix.model.Usuario;
import java.util.ArrayList;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
@RequestMapping("api")
public class LeonixController {

	@GetMapping("/teste")
	public String teste(@RequestParam(name = "nome", required = false, defaultValue = "World") String nome) {
		return "Seu nome é ".concat(nome);
	}

	@GetMapping("/usuarios")
	public String obterUsuarios() {
		ArrayList<Usuario> usuarios = new ArrayList<>();

		for (int i = 0; i < 10; i++) {
			Usuario usr = new Usuario();
			usr.setId(i);
			usr.setNick("usuário " + i);
			usr.setSenha(((Integer) (i * 10 / 2)).toString());
			usuarios.add(usr);
		}

		UsuarioAdapter usrAdapter = new UsuarioAdapter(usuarios);

		return usrAdapter.getJson();
	}

	@GetMapping("/logar")
	public String efetuarLogin(@RequestParam(name = "nick", required = true) String nick,
			@RequestParam(name = "senha", required = true) String senha) {


		System.out.println("QUEVEIO : " + nick + " | " + senha);
		
		for (Usuario usr : Statics.usuarios) {
			System.out.println("BANCO : " + usr.getNick() + " | " + usr.getSenha());
			if (usr.getNick().equals(nick) && usr.getSenha().equals(senha)) {
				return "{\"status\":0}";
			}
		}

		return "{\"status\":1}";
	}

	@GetMapping("/cadastrar")
	public String efetuarCadastro(@RequestParam(name = "nick", required = true) String nick,
			@RequestParam(name = "senha", required = true) String senha) {

		for (Usuario usr : Statics.usuarios) {
			if (usr.getNick().equals(nick)) {
				return "{\"status\":1}";
			}
		}

		Usuario usuario = new Usuario();
		usuario.setNick(nick);
		usuario.setSenha(senha);
		
		System.out.println("QUEVEIO : " + nick + " | " + senha);
		
		Statics.usuarios.add(usuario);

		return "{\"status\":0}";
	}

	@GetMapping("/amigos")
	public String obterAmigos(@RequestParam(name = "idUsuarioA", required = true) Integer idUsuarioA,
			@RequestParam(name = "idUsuarioB", required = true) Integer idUsuarioB) {

		ArrayList<Amigo> amigos = new ArrayList<>();

		for (int i = 0; i < 3000; i++) {
			Amigo amigo = new Amigo();
			amigo.setId(i);
			amigo.setIdUsuarioA(1);
			amigo.setIdUsuarioB(3);
			amigos.add(amigo);
		}

		AmigoAdapter amgAdapter = new AmigoAdapter(amigos);

		return amgAdapter.getJson();
	}

	@GetMapping("/chats")
	public String obterChat(@RequestParam(name = "idUsuarioA", required = false) Integer idUsuarioA,
			@RequestParam(name = "idUsuarioB", required = false) Integer idUsuarioB) {

		ArrayList<Chat> chats = new ArrayList<>();

		for (int i = 0; i < 3000; i++) {
			Chat chat = new Chat();
			chat.setId(i);
			chat.setIdUsuarioA(1);
			chat.setIdUsuarioB(3);
			chats.add(chat);
		}

		ChatAdapter chatAdapter = new ChatAdapter(chats);

		return chatAdapter.getJson();
	}

}
