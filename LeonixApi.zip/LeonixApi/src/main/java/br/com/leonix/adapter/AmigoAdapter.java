package br.com.leonix.adapter;

import java.util.ArrayList;
import br.com.leonix.model.Amigo;

public class AmigoAdapter {

	private Amigo amigo = null;

	private ArrayList<Amigo> amigos = null;

	public AmigoAdapter(Amigo amigo) {
		this.amigo = amigo;
	}
	
	public AmigoAdapter(ArrayList<Amigo> amigos) {
		this.amigos = amigos;
	}
	
	public String getJson() {
		
		String jsonStr = "";
		
		if (this.amigo != null) {
			jsonStr = String.format("{\"id\":%s,\"idUsuarioA\":\"%s\",\"idUsuarioB\":\"%s\"}", this.amigo.getId(),
					this.amigo.getIdUsuarioA(), this.amigo.getIdUsuarioB());
		} else if (this.amigos != null) {
			jsonStr = "[";
			for (Amigo amg : this.amigos) {
				if (amg.equals(this.amigos.get(this.amigos.size() - 1))) {
					jsonStr += String.format("{\"id\":%s,\"idUsuarioA\":\"%s\",\"idUsuarioB\":\"%s\"}", amg.getId(),
							amg.getIdUsuarioA(), amg.getIdUsuarioB());
				} else {
					jsonStr += String.format("{\"id\":%s,\"idUsuarioA\":\"%s\",\"idUsuarioB\":\"%s\"},", amg.getId(),
							amg.getIdUsuarioA(), amg.getIdUsuarioB());
				}
			}
			jsonStr += "]";
		}
		return jsonStr;
	}
}
