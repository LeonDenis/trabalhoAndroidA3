package br.com.leonix.api;

import java.util.ArrayList;

import br.com.leonix.model.Usuario;

public class Statics {

	public static ArrayList<Usuario> usuarios = new ArrayList<>();
	
}
